import { BusDetails } from './bus-details';

describe('BusDetails', () => {
  it('should create an instance', () => {
    expect(new BusDetails()).toBeTruthy();
  });
});
