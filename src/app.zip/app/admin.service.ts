import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Admin } from './admin';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  
  constructor(private httpClient: HttpClient) { }

  private baseURL = "http://localhost:8080/api/admins";

  registerAdmin(name: string, emailId: string, password: string, phoneNumber: string): Observable<any> {
    const url = `${this.baseURL}/registerAdmin`;
    const payload = {
     name: name,
      emailId: emailId,
      password: password,
      phoneNumber: phoneNumber
    };

    return this.httpClient.post<any>(url, payload);
  }

  loginAdmin(emailId: string, password: string): Observable<Admin> {
    return this.httpClient.get<Admin>(`${this.baseURL}/loginAdmin/${emailId}/${password}`);
  }

  getAllAdmin(): Observable<Admin[]> {
    return this.httpClient.get<Admin[]>(`${this.baseURL}/getAllAdmin`);
  }

  getAdminById(adminId: number): Observable<Admin> {
    return this.httpClient.get<Admin>(`${this.baseURL}/getAdminById/${adminId}`);
  }

  getAdminByEmail(emailId: string): Observable<Admin> {
    return this.httpClient.get<Admin>(`${this.baseURL}/getAdminByEmail/${emailId}`);
  }

  updateAdminPassword(adminId: any, newPassword: string): Observable<any> {
    return this.httpClient.put<Admin>(`${this.baseURL}/updateAdminPassword/${adminId}/${newPassword}`, null);
  }

  updateAdminById(adminId: any, admin: Admin): Observable<any> {
    return this.httpClient.put<Admin>(`${this.baseURL}/updateAdminById/${adminId}`, admin);
  }

  deleteAdminById(adminId: any): Observable<any> {
    return this.httpClient.delete<string>(`${this.baseURL}/deleteAdminById/${adminId}`);
  }
}
