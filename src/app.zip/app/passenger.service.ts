import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Passenger } from './passenger';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})

export class PassengerService {
 
  
  constructor(private httpClient:HttpClient) { }

  private baseURL = "http://localhost:8080/api/passengers";

  registerPassenger(passName: string, emailId: string, password: string, phoneNumber: string): Observable<any> {
    const url = `${this.baseURL}/registerPassenger`;
    const payload = {
      passName: passName,
      emailId: emailId,
      password: password,
      phoneNumber: phoneNumber
    };

    return this.httpClient.post<any>(url, payload);
  }

  

  loginPassenger(emailId: string, password: string): Observable<Passenger> {
    return this.httpClient.get<Passenger>(`${this.baseURL}/loginPassenger/${emailId}/${password}`);
  }

  getAllPassengers(): Observable<Passenger[]> {
    return this.httpClient.get<Passenger[]>(`${this.baseURL}/getAllPassengers`);
  }

  getPassengerById(passId: number): Observable<Passenger> {
    return this.httpClient.get<Passenger>(`${this.baseURL}/getPassengerById/${passId}`);
  }

  updatePassengerById(passId: any, passenger: Passenger): Observable<any> {
    return this.httpClient.put<Passenger>(`${this.baseURL}/updatePassengerById/${passId}`, passenger);
  }

  deletePassengerById(passId: any): Observable<any> {
    return this.httpClient.delete<string>(`${this.baseURL}/deletePassengerById/${passId}`);
  }

  getPassengersBySourceAndDestination(source: string, destination: string): Observable<Passenger[]> {
    return this.httpClient.get<Passenger[]>(`${this.baseURL}/${source}/${destination}`);
  }

  getPassengersByArrivalDateTime(arrivalDateTime: string): Observable<Passenger[]> {
    return this.httpClient.get<Passenger[]>(`${this.baseURL}/${arrivalDateTime}`);
 
  }
  
}
