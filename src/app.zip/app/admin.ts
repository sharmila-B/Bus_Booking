export class Admin {

    adminId: number | undefined;
    name: String | undefined;
    emailId: String | undefined;
    phoneNumber: String | undefined;
    password: String | undefined;
}
