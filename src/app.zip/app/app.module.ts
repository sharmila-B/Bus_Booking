import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { AccountComponent } from './account/account.component';
import { BusDetailsComponent } from './components/bus-details/bus-details.component';
import { TicketsComponent } from './components/tickets/tickets.component';
import { AddBusComponent } from './components/admin/add-bus/add-bus.component';
import { BusListComponent } from './components/admin/bus-list/bus-list.component';
import { DeleteBusComponent } from './components/admin/delete-bus/delete-bus.component';
import { LogoutComponent } from './components/admin/logout/logout.component';
import { PassengerListComponent } from './components/admin/passenger-list/passenger-list.component';
import { UpdateBusComponent } from './components/admin/update-bus/update-bus.component';
import { ViewTicketsComponent } from './components/admin/view-tickets/view-tickets.component';
import { AdminLoginComponent } from './components/admin/admin-login/admin-login.component';
import { AdminSignupComponent } from './components/admin/admin-signup/admin-signup.component';
import { BookBusComponent } from './components/passenger/book-bus/book-bus.component';
import { DeletePassengerComponent } from './components/passenger/delete-passenger/delete-passenger.component';
import { UpdatePassengerComponent } from './components/passenger/update-passenger/update-passenger.component';
import { PassengerLoginComponent } from './components/passenger/passenger-login/passenger-login.component';
import { PassengerSignupComponent } from './components/passenger/passenger-signup/passenger-signup.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    AccountComponent,
    BusDetailsComponent,
    TicketsComponent,
    AddBusComponent,
    BusListComponent,
    DeleteBusComponent,
    LogoutComponent,
    PassengerListComponent,
    UpdateBusComponent,
    ViewTicketsComponent,
    AdminLoginComponent,
    AdminSignupComponent,
    BookBusComponent,
    DeletePassengerComponent,
    UpdatePassengerComponent,
    PassengerLoginComponent,
    PassengerSignupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
