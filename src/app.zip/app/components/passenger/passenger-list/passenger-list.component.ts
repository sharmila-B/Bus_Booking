import { Component } from '@angular/core';

@Component({
  selector: 'app-passenger-list',
  templateUrl: './passenger-list.component.html',
  styleUrl: './passenger-list.component.css'
})
export class PassengerListComponent {

}
