import { Component } from '@angular/core';

@Component({
  selector: 'app-view-tickets',
  templateUrl: './view-tickets.component.html',
  styleUrl: './view-tickets.component.css'
})
export class ViewTicketsComponent {

}
