import { Component } from '@angular/core';

@Component({
  selector: 'app-passenger-signup',
  templateUrl: './passenger-signup.component.html',
  styleUrl: './passenger-signup.component.css'
})
export class PassengerSignupComponent {

}
