import { Component } from '@angular/core';

@Component({
  selector: 'app-update-passenger',
  templateUrl: './update-passenger.component.html',
  styleUrl: './update-passenger.component.css'
})
export class UpdatePassengerComponent {

}
