import { Component, OnInit } from '@angular/core';
import { BusDetailsService } from '../../../bus-details.service';
import { BusDetails } from '../../../bus-details';
import { Observable } from 'rxjs';
import { Passenger } from '../../../passenger';

@Component({
  selector: 'app-bus-list',
  templateUrl: './bus-list.component.html',
  styleUrls: ['./bus-list.component.css']
})
export class BusListComponent implements OnInit {

  bus: BusDetails= new BusDetails();
  buses$: Observable<BusDetails[]> | undefined;
  buses: BusDetails[] | undefined;
  
  busNumber: any;
  /* source: string | undefined;
  destination: string | undefined;*/
  
  passenger: Passenger= new Passenger();

  busNumberInvalid = false;


  constructor(private busdetailservice: BusDetailsService) { }

  ngOnInit(): void {
    this.findAllBuses();
  }

  findAllBuses(): void {
    this.busdetailservice.findAll().subscribe(
      (buses: BusDetails[]) => {
        this.buses = buses;
      },
      (error) => {
        console.error('Error fetching buses:', error);
      }
    );
  }

  getBusByNumber(busNumber: number): void {
    this.busNumberInvalid = !busNumber;
    if (!this.busNumberInvalid) {
      this.busdetailservice.getBusByNumber(busNumber).subscribe(
        (bus: BusDetails) => {
          console.log('Bus details:', bus);
        },
        (error) => {
          console.error('Error fetching bus details:', error);
        }
      );
    }
  }

  searchBuses(source:string, destination:string): void {
    if (this.bus.source && this.bus.destination) {
      this.buses$ = this.busdetailservice.getBusBySourceAndDestination(source, destination);
    }
  }
}
