import { Component } from '@angular/core';
import { Ticket } from '../../../tickets';
import { TicketService } from '../../../tickets.service';
import { Passenger } from '../../../passenger';

@Component({
  selector: 'app-book-bus',
  templateUrl: './book-bus.component.html',
  styleUrl: './book-bus.component.css'
})
export class BookBusComponent {

  ticket: Ticket = new Ticket();
  passenger: Passenger = new Passenger();

  constructor(private ticketservice: TicketService) { }

  addTicket(): void {
    this.ticketservice.addTicket(this.ticket)
      .subscribe(
        (response) => {
          // Handle successful ticket addition response here
          console.log('Ticket added successfully:', response);
          // You may want to refresh the ticket list or show a success message
        },
        (error) => {
          // Handle error response here
          console.error('Failed to add ticket:', error);
          // You may want to display an error message to the user
        }
      );
  }

  updateTicket(ticket: Ticket): void {
    this.ticketservice.updateTicket(ticket)
      .subscribe(
        (response) => {
          // Handle successful ticket update response here
          console.log('Ticket updated successfully:', response);
          // You may want to refresh the ticket list or show a success message
        },
        (error) => {
          // Handle error response here
          console.error('Failed to update ticket:', error);
          // You may want to display an error message to the user
        }
      );
  }



}

