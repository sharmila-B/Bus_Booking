import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationserviceService } from '../../../authenticationservice.service';


@Component({
  selector: 'app-passenger-login',
  templateUrl: './passenger-login.component.html',
  styleUrl: './passenger-login.component.css'
})
export class PassengerLoginComponent {
  
    emailId: string = '';
    password: string = '';
  
    constructor(private authService: AuthenticationserviceService, private router: Router) { }
  
    login(): void {
      this.authService.passengerlogin(this.emailId, this.password)
        .subscribe(
          (loggedIn: boolean) => {
            if (loggedIn) {
              // Navigate to passenger dashboard if login is successful
              this.router.navigate(['/passengers/dashboard']);
            } else {
              // Handle login failure
              console.error('Failed to login. Invalid credentials.');
            }
          },
          (error: any) => {
            console.error('Error during login:', error);
          }
        );
    }
    signup(){
      this.router.navigate(['components/pasenger/passenger-signup']);
  
    }
  }


