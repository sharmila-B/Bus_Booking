import { Component } from '@angular/core';
import { AuthenticationserviceService } from '../../../authenticationservice.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent {
  constructor(private authService: AuthenticationserviceService) { }

  logout(): void {
    this.authService.adminlogout();
  }
}
