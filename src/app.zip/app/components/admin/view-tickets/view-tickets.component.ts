import { Component, OnInit } from '@angular/core';
import { TicketService } from '../../../tickets.service';
import { Ticket } from '../../../tickets';


@Component({
  selector: 'app-view-tickets',
  templateUrl: './view-tickets.component.html',
  styleUrl: './view-tickets.component.css'
})
export class ViewTicketsComponent implements OnInit {

  ticket: Ticket = new Ticket();
  ticketId: any;

  constructor(private ticketservice:TicketService){}
  ngOnInit(): void {
   
    this.findById(1); 
  }

  findById(ticketId: number): void {
    this.ticketservice.findById(ticketId).subscribe(
      (ticket: Ticket) => {
        console.log('Ticket found:', ticket); 
      },
      (error) => {
        console.error('Error finding ticket:', error);
      }
    );
  }
  deleteTicket(ticketId: number): void {
    this.ticketservice.delete(ticketId).subscribe(
      (response) => {
        console.log('Ticket deleted successfully:', response);
      },
      (error) => {
        console.error('Error deleting ticket:', error);
      }
    );
  }

}

