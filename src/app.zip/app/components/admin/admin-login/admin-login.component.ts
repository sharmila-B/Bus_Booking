import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationserviceService } from '../../../authenticationservice.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrl: './admin-login.component.css'
})
export class AdminLoginComponent {
  emailId: string = '';
  password: string = '';

  constructor(private authService: AuthenticationserviceService, private router: Router) { }

  login(): void {
    this.authService.adminlogin(this.emailId, this.password)
      .subscribe(
        (loggedIn: boolean) => {
          if (loggedIn) {
            // Navigate to admin dashboard if login is successful
            this.router.navigate(['/admin/dashboard']);
          } else {
            // Handle login failure
            console.error('Failed to login. Invalid credentials.');
          }
        },
        (error: any) => {
          console.error('Error during login:', error);
        }
      );
  }
  signup(){
    this.router.navigate(['components/admin/admin-signup']);

  }
}
