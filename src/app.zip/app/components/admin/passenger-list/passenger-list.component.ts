import { Component, OnInit } from '@angular/core';
import { Passenger } from '../../../passenger';
import { PassengerService } from '../../../passenger.service';

@Component({
  selector: 'app-passenger-list',
  templateUrl: './passenger-list.component.html',
  styleUrl: './passenger-list.component.css'
})
export class PassengerListComponent implements OnInit {
  passengers: any;
  source: string = '';
  destination: string = '';
  arrivalDateTime: string = '';
  passId: any | undefined;

    constructor(private passengerservice:PassengerService) { }

  ngOnInit(): void {
    this.getAllPassengers();
  }

  public getAllPassengers() {
    this.passengerservice.getAllPassengers().subscribe(data => {
      this.passengers = data;
    });
  }
  getPassengerById(): void {
    this.passengerservice.getPassengerById(this.passId).subscribe(
      (passenger: Passenger) => {
        console.log('Passenger:', passenger);
      },
      (error: any) => {
        console.error('Error:', error);
      }
    );
  }
  passengerId(passengerId: any) {
    throw new Error('Method not implemented.');
  }
  getPassengersBySourceAndDestination(): void {
    this.passengerservice.getPassengersBySourceAndDestination(this.source, this.destination)
      .subscribe((passengers: any) => {
        // Handle the response from the service if needed
        console.log(passengers);
      });
  }

  getPassengersByArrivalDateTime(): void {
    this.passengerservice.getPassengersByArrivalDateTime(this.arrivalDateTime)
      .subscribe((passengers: any) => {
        // Handle the response from the service if needed
        console.log(passengers);
      });
}
}


