import { Component, OnInit } from '@angular/core';
import { BusDetails } from '../../../bus-details';
import { BusDetailsService } from '../../../bus-details.service';

@Component({
  selector: 'app-bus-list',
  templateUrl: './bus-list.component.html',
  styleUrl: './bus-list.component.css'
})
export class BusListComponent implements OnInit {
  details: any;
  bus: any;
  buses: any;
  constructor(private busdetailserive: BusDetailsService) { }
  ngOnInit(): void {

    this.findAllBuses();
  }


  findAllBuses(): void {
    this.busdetailserive.findAll().subscribe(
      (buses: BusDetails[]) => {
        console.log(buses);
      },
      (error) => {
        console.error('Error fetching buses:', error);
      }
    );
  }

  getBusByNumber(busNumber: number): void {
    this.busdetailserive.getBusByNumber(busNumber).subscribe(
      (bus: BusDetails) => {
        console.log('Bus details:', bus);
      },
      (error) => {
        console.error('Error fetching bus details:', error);
      }
    );
  }

}

