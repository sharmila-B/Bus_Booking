import { Component } from '@angular/core';
import { AdminService } from '../../../admin.service';

@Component({
  selector: 'app-admin-signup',
  templateUrl: './admin-signup.component.html',
  styleUrl: './admin-signup.component.css'
})
export class AdminSignupComponent {
  name: string = '';
  emailId: string = '';
  password: string = '';
  phoneNumber: string = '';
  
  constructor(private adminservice: AdminService) { }
  
  registerAdmin(): void {
    this.adminservice.registerAdmin(this.name, this.emailId, this.password, this.phoneNumber)
      .subscribe(
        (response) => {
          console.log(' registered successfully:', response);
          // You may want to redirect the user or show a success message
        },
        (error) => {
          console.error('Failed to register', error);
          // You may want to display an error message to the user
        }
      );
  }
}
